package senha;

public class PilhaChar {

	public final int N = 50;

	char dados[] = new char[N];
	int topo;

	public void init() {
		topo = 0;
	}

	public boolean isFull() {
		if (topo == N) {
			return true;
		} else {
			return false;
		}
	}

	public boolean isEmpty() {
		if (topo == 0) {
			return true;
		} else {
			return false;
		}
	}

	public void push(char elem) {
		if (isFull()) {
			System.out.println("Pilha cheia!");
		} else {
			dados[topo] = elem;
			topo++;
		}
	}

	public static class RetornoChar {
		char elem;
		boolean sucesso;
	}

	public RetornoChar pop() {
		RetornoChar saida = new RetornoChar();
		if (isEmpty()) {
			saida.sucesso = false;
		} else {
			topo--;
			saida.elem = dados[topo];
			saida.sucesso = true;
		}
		return saida;
	}
	
	
	
	

}
