package senha;

import java.util.Scanner;
import senha.PilhaChar.RetornoChar;

public class SalvaSenha {

	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);
		RetornoChar res = new RetornoChar();
		PilhaChar pilha = new PilhaChar();
		pilha.init();

		String senha = new String();
		String alterada = new String();

		System.out.print("Digite a senha: ");
		senha = teclado.nextLine();

		for (int i = 0; i < senha.length(); i++) {
			if (senha.charAt(i) != '_' && senha.charAt(i) != '#') {
				pilha.push(senha.charAt(i));
			} else {
				res = pilha.pop();
				while (res.sucesso) {
					alterada += res.elem;
					res = pilha.pop();
				}
				alterada += senha.charAt(i);
			}

		}

		System.out.println("Senha alterada: " + alterada);

		teclado.close();

	}

}